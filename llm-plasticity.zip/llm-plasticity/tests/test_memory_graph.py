import sys
import time
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from plasticity.memory_graph import MemoryGraph


def fresh_graph(**kwargs):
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return MemoryGraph(tmp.name, **kwargs)


def test_record_exchange_creates_nodes_and_edges():
    g = fresh_graph()
    g.record_exchange(["python", "memory leaks", "garbage collection"])
    stats = g.stats()
    assert stats["nodes"] == 3
    assert stats["edges"] == 3  # complete graph over 3 concepts
    print("OK: nodes/edges created")


def test_reinforcement_increases_weight():
    g = fresh_graph()
    g.record_exchange(["rust", "borrow checker"])
    w1 = dict(g.neighbors("rust"))["borrow checker"]
    g.record_exchange(["rust", "borrow checker"])
    w2 = dict(g.neighbors("rust"))["borrow checker"]
    assert w2 > w1, f"expected reinforcement, got {w1} -> {w2}"
    print(f"OK: reinforcement {w1:.3f} -> {w2:.3f}")


def test_decay_reduces_weight_over_simulated_time():
    g = fresh_graph(decay_half_life_seconds=1.0)  # 1 second half life for testability
    g.record_exchange(["ibx", "claims"])
    w_immediate = dict(g.neighbors("ibx"))["claims"]
    time.sleep(1.2)
    w_after = dict(g.neighbors("ibx"))["claims"]
    assert w_after < w_immediate, f"expected decay, got {w_immediate} -> {w_after}"
    assert w_after < w_immediate * 0.6
    print(f"OK: decay {w_immediate:.3f} -> {w_after:.3f} after 1.2s (half-life=1s)")


def test_canonicalization_merges_case_and_whitespace_variants():
    g = fresh_graph()
    g.record_exchange(["Docker", "containers"])
    g.record_exchange(["  docker ", "Kubernetes"])
    neighbors = dict(g.neighbors("docker"))
    assert "containers" in neighbors
    assert "kubernetes" in neighbors
    assert g.stats()["nodes"] == 3
    print("OK: canonicalization merges variants")


def test_spreading_activation_surfaces_indirect_associations():
    g = fresh_graph()
    # sewer gas -> PWD case -> attorney  (a chain, like Michael's actual situation)
    g.record_exchange(["sewer gas", "pwd case"])
    g.record_exchange(["pwd case", "attorney xavier"])
    results = g.spreading_activation(["sewer gas"], depth=2)
    labels = [r.label for r in results]
    assert "pwd case" in labels
    assert "attorney xavier" in labels, f"expected 2-hop spread to reach attorney xavier, got {labels}"
    # 1-hop should activate more strongly than 2-hop
    scores = {r.label: r.activation for r in results}
    assert scores["pwd case"] > scores["attorney xavier"]
    print(f"OK: spreading activation -> {labels} with scores {scores}")


def test_forget_removes_node_and_edges():
    g = fresh_graph()
    g.record_exchange(["a", "b"])
    assert g.forget("a") is True
    assert g.stats()["nodes"] == 1
    assert g.neighbors("b") == []
    print("OK: forget removes node + incident edges")


def test_edge_weight_is_capped():
    g = fresh_graph(max_edge_weight=3.0, reinforcement_gain=1.0)
    for _ in range(10):
        g.record_exchange(["x", "y"])
    w = dict(g.neighbors("x"))["y"]
    assert w <= 3.0
    print(f"OK: weight capped at {w}")


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
    print(f"\n{len(tests)} tests passed.")
