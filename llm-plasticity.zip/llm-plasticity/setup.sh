#!/usr/bin/env bash
# Setup for llm-plasticity on Apple Silicon macOS.
set -euo pipefail

if [[ "$(uname)" != "Darwin" ]]; then
    echo "This tool targets macOS on Apple Silicon (MLX doesn't run elsewhere)."
    exit 1
fi
if [[ "$(uname -m)" != "arm64" ]]; then
    echo "Warning: MLX requires Apple Silicon (M1/M2/M3/M4). Intel Macs are not supported."
fi

echo "Creating virtual environment..."
python3 -m venv .venv
source .venv/bin/activate

echo "Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "Setup complete. Run with:"
echo "  source .venv/bin/activate"
echo "  python -m plasticity.cli"
echo ""
echo "First run downloads the model weights (~2GB for the default model) and caches them"
echo "in ~/.cache/huggingface -- after that, startup is fast and fully offline."
